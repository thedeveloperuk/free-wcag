<!-- Placeholder for a file that will be used to tag images with alt tags
by check if they have a membership active and using our API key
-->